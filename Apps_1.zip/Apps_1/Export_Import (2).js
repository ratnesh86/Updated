module.exports.fun = function()
    {
        console.log("World is big");
    }

module.exports.names=["Rob","Rahul","Ravi"];