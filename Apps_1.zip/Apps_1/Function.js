function fun()
{
    console.log("test");
}

console.log(fun());

