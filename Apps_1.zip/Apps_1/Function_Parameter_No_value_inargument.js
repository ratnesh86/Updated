function fun(a)
{
    return "Hi!!" + a;
}

function fun1(a,b)
{
    return "check" + a;
}

function fun2(a,b)
{
    return "check" + a;
}

console.log(fun());

console.log(fun1("ratnesh"));

console.log(fun2("ratnesh"));