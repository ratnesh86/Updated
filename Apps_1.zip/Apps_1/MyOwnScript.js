class test
{
    sum(num1,num2)
    {
        num3 = num1 + num2;
    }

    display()
    {
        console.log(this.num3); 
    }
}

