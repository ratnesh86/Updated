var os=require('os');
var fs=require('fs');
var obj=require('./Export_Import');                                   //./ means current folder. if this is in a differt folder we need to give that name

console.log(os.arch());
console.log(os.freemem());
console.log(os.platform());

/*fs.readFile("package.json",'utf8',function(err,data)
    {
        if(err)
            console.log("error in reading file");
        else
            console.log(data);
    }
    )
*/
console.log("after reading the file");

obj.fun();
console.log(obj.names);