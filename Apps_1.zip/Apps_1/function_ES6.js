var a = function()
    {
        return "Hello Workd";
    }

console.log(a());

var b=()=>"Hello Ratnesh";

console.log(b());

var n=(z)=>"Hello "+z;
console.log(n(" Ratnesh Pandey"));

var test=()=>{
    console.log("line1");
    console.log("line2");
}

test();