var temp=require('nodeproject-12june');

console.log(temp.appname);

temp.home();

temp.lib.global();